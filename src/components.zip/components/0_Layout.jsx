import { Outlet, useLocation } from 'react-router-dom';
import { createContext, useContext } from 'react';
import Header from "../components/1_header";
import NavMenu from "../components/2_NavMenu";
import Footer from "../components/3_Footer";
import MobileHeader from "../components/1_MobileHeader";
import MobileNavMenu from "../components/2_MobileNavMenu";
import { useEffect, useRef, useState } from 'react';

export const ScaleContext = createContext();

const Layout = () => {
  const [scale, setScale] = useState(1);
  const [mobileScale, setMobileScale] = useState(1);
  const [isMobile, setIsMobile] = useState(false);
  const [isMobileNav, setIsMobileNav] = useState(false);
  const [contentHeight, setContentHeight] = useState(null);
  const { pathname } = useLocation();
  const scrollContainerRef = useRef();
  const contentRef = useRef();
  const outletRef = useRef();
  const footerRef = useRef();
  const isScrollingRef = useRef(false);
  const scrollTimeoutRef = useRef(null);
  const lastScrollDeltaY = useRef(0);

  useEffect(() => {
    if (window.__isModalOpen) return;
    if (pathname.includes("surveyform")) return;
    if (scrollContainerRef.current) scrollContainerRef.current.scrollTop = 0;
  }, [pathname]);

  useEffect(() => {
    const handleResize = () => {
      const screenWidth = window.innerWidth;
      if (screenWidth <= 819) {
        setIsMobileNav(true);
        setMobileScale(screenWidth / 393);
      } else {
        setIsMobileNav(false);
        setMobileScale(1);
      }
      if (screenWidth <= 1200) {
        setIsMobile(true);
        setScale(screenWidth / 1200);
      } else {
        setIsMobile(false);
        setScale(screenWidth >= 1920 ? screenWidth / 1920 : 1);
      }
    };
    window.addEventListener('resize', handleResize);
    handleResize();
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  useEffect(() => {
    const updateContentHeight = () => {
      let totalHeight = 0;
      if (outletRef.current) totalHeight += outletRef.current.getBoundingClientRect().height;
      if (footerRef.current) totalHeight += footerRef.current.getBoundingClientRect().height;
      setContentHeight(totalHeight + 100);
    };
    const resizeObserver = new ResizeObserver(updateContentHeight);
    if (outletRef.current) resizeObserver.observe(outletRef.current);
    if (footerRef.current) resizeObserver.observe(footerRef.current);
    setTimeout(updateContentHeight, 50);
    return () => {
      if (outletRef.current) resizeObserver.unobserve(outletRef.current);
      if (footerRef.current) resizeObserver.unobserve(footerRef.current);
    };
  }, [isMobile, scale, pathname]);

  // 향상된 스크롤 이벤트 핸들러
  const handleGlobalScroll = (e) => {
    if (!scrollContainerRef.current) return;
    
    // 현재 스크롤 관련 정보
    const scrollContainer = scrollContainerRef.current;
    const currentScrollTop = scrollContainer.scrollTop;
    const maxScrollTop = scrollContainer.scrollHeight - scrollContainer.clientHeight;
    
    // 스크롤 관성 효과 구현을 위한 계산
    const speedFactor = 1.2; // 스크롤 속도 조절 (1보다 크면 더 빠르게)
    const deltaY = e.deltaY * speedFactor;
    lastScrollDeltaY.current = deltaY;
    
    // 1. 경계 도달 시 처리 - 부드럽게 멈추기
    if ((currentScrollTop <= 0 && deltaY < 0) || 
        (currentScrollTop >= maxScrollTop && deltaY > 0)) {
      if (!isScrollingRef.current) {
        // 이미 경계에 있으면 브라우저의 자체 스크롤 허용 (약간의 바운스 허용)
        return;
      }
    }
    
    // 2. 정상 스크롤 실행
    const newScrollTop = Math.max(0, Math.min(maxScrollTop, currentScrollTop + deltaY));
    scrollContainer.scrollTop = newScrollTop;
    
    // 진행 중인 스크롤 감지
    isScrollingRef.current = true;
    e.preventDefault(); // 브라우저 기본 스크롤 방지
    
    // 스크롤 종료 감지
    clearTimeout(scrollTimeoutRef.current);
    scrollTimeoutRef.current = setTimeout(() => {
      isScrollingRef.current = false;
    }, 150); // 스크롤이 150ms 동안 없으면 스크롤 종료로 간주
  };
  
  // 터치 이벤트 처리
  useEffect(() => {
    let touchStartY = 0;
    let lastTouchY = 0;
    let touchVelocity = 0;
    let isTouching = false;
    let momentumInterval = null;
    
    // 터치 시작
    const handleTouchStart = (e) => {
      if (!scrollContainerRef.current) return;
      
      // 다른 모멘텀 스크롤링 중지
      clearInterval(momentumInterval);
      
      touchStartY = e.touches[0].clientY;
      lastTouchY = touchStartY;
      touchVelocity = 0;
      isTouching = true;
    };
    
    // 터치 이동
    const handleTouchMove = (e) => {
      if (!isTouching || !scrollContainerRef.current) return;
      
      const scrollContainer = scrollContainerRef.current;
      const currentY = e.touches[0].clientY;
      const deltaY = lastTouchY - currentY;
      
      // 속도 계산
      touchVelocity = deltaY * 0.8 + touchVelocity * 0.2;
      
      // 스크롤 적용
      scrollContainer.scrollTop += deltaY;
      
      lastTouchY = currentY;
      e.preventDefault();
    };
    
    // 터치 종료 - 모멘텀 스크롤링
    const handleTouchEnd = (e) => {
      if (!isTouching || !scrollContainerRef.current) return;
      
      isTouching = false;
      const scrollContainer = scrollContainerRef.current;
      
      // 모멘텀 스크롤링 구현
      if (Math.abs(touchVelocity) > 1) {
        let velocity = touchVelocity;
        let decay = 0.94; // 마찰 계수
        
        momentumInterval = setInterval(() => {
          if (Math.abs(velocity) < 0.5) {
            clearInterval(momentumInterval);
            return;
          }
          
          // 경계 체크
          const maxScroll = scrollContainer.scrollHeight - scrollContainer.clientHeight;
          const newScrollTop = scrollContainer.scrollTop + velocity;
          
          if (newScrollTop < 0 || newScrollTop > maxScroll) {
            // 경계에 닿으면 빠르게 감속
            velocity *= 0.5;
          }
          
          scrollContainer.scrollTop += velocity;
          velocity *= decay;
        }, 16); // ~60fps
      }
    };
    
    // 이벤트 리스너 등록
    window.addEventListener('touchstart', handleTouchStart, { passive: false });
    window.addEventListener('touchmove', handleTouchMove, { passive: false });
    window.addEventListener('touchend', handleTouchEnd);
    
    return () => {
      window.removeEventListener('touchstart', handleTouchStart);
      window.removeEventListener('touchmove', handleTouchMove);
      window.removeEventListener('touchend', handleTouchEnd);
      clearInterval(momentumInterval);
    };
  }, []);

  // 스크롤바 표시/숨김 토글 기능
  const [showScrollbar, setShowScrollbar] = useState(false);
  
  useEffect(() => {
    const handleMouseMove = () => {
      setShowScrollbar(true);
      clearTimeout(window.scrollbarTimeout);
      window.scrollbarTimeout = setTimeout(() => {
        setShowScrollbar(false);
      }, 1500);
    };
    
    window.addEventListener('mousemove', handleMouseMove);
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      clearTimeout(window.scrollbarTimeout);
    };
  }, []);

  const OutletWrapper = () => (
    <div ref={outletRef}>
      <Outlet />
      <div ref={footerRef}>
        <Footer />
      </div>
    </div>
  );

  return (
    <ScaleContext.Provider value={scale}>
      <div className="min-h-screen flex flex-col overflow-hidden">
        {isMobileNav ? (
          <>
            <MobileHeader mobileScale={mobileScale} className="fixed top-0 left-0 w-full z-50" style={{ width: '100vw' }} />
            <MobileNavMenu mobileScale={mobileScale} className="fixed top-[52px] left-0 w-full z-40" style={{ width: '100vw' }} />
          </>
        ) : (
          <>
            <Header className="fixed top-0 left-0 w-full z-50" />
            <NavMenu className="fixed top-[80px] left-0 w-full z-40" />
          </>
        )}
        <div
          ref={scrollContainerRef}
          className="flex-1 flex justify-center items-start overflow-x-hidden overflow-y-auto bg-white scroll-smooth"
          style={{ 
            minHeight: '100vh',
            height: '100vh',
            scrollbarWidth: showScrollbar ? 'thin' : 'none', // Firefox
            msOverflowStyle: showScrollbar ? 'auto' : 'none', // IE/Edge
          }}
        >
          <div
            ref={contentRef}
            className="flex justify-center w-full"
            style={{
              height: isMobile && contentHeight ? `calc(${contentHeight}px * ${scale})` : 'auto',
              minHeight: '100vh',
            }}
          >
            <div
              className="flex flex-col w-full"
              style={{
                width: '1920px',
                transform: `scale(${scale})`,
                transformOrigin: 'top center',
                minHeight: isMobile ? '100%' : 'auto',
              }}
            >
              <div style={{ paddingTop: isMobileNav ? '104px' : '160px' }}>
                <OutletWrapper />
              </div>
            </div>
          </div>
        </div>
        <style jsx>{`
          div {
            scroll-behavior: smooth;
          }
          
          /* 스크롤바 기본 숨김 (WebKit 브라우저용) */
          div::-webkit-scrollbar {
            width: ${showScrollbar ? '8px' : '0'};
            background-color: transparent;
            transition: width 0.3s;
          }
          
          /* 스크롤바 썸(Thumb) 스타일 */
          div::-webkit-scrollbar-thumb {
            background-color: rgba(156, 163, 175, 0.5);
            border-radius: 4px;
          }
          
          /* 스크롤바 썸 호버 효과 */
          div::-webkit-scrollbar-thumb:hover {
            background-color: rgba(107, 114, 128, 0.7);
          }
        `}</style>
      </div>
      
      {/* 전역 스크롤 이벤트 리스너 - 향상된 버전 */}
      <div 
        style={{
          position: 'fixed',
          top: 0,
          left: 0,
          width: '100%',
          height: '100%',
          pointerEvents: 'none',
          zIndex: -1
        }}
        onWheel={handleGlobalScroll}
      />
    </ScaleContext.Provider>
  );
};

export default Layout;