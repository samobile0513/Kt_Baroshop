import React, { useEffect, useRef, useState, useContext } from 'react';
import { ScaleContext } from './0_Layout';
import TermsModal from './TermsModal';
import Info1 from './other/info1';
import Info2 from './other/info2';
import Info3 from './other/info3';

const Footer = () => {
  const [openModal, setOpenModal] = useState(null);
  const [scrollY, setScrollY] = useState(0);
  const [footerScale, setFooterScale] = useState(1);
  const contentRef = useRef(null);
  const [adjustedHeight, setAdjustedHeight] = useState('auto');
  const [loaded, setLoaded] = useState(false);
  const layoutScale = useContext(ScaleContext);

  useEffect(() => {
    const handleResize = () => {
      const width = window.innerWidth;

      if (width <= 390) {
        setFooterScale(0.7);
      } else if (width <= 1200) {
        setFooterScale(0.8);
      } else {
        setFooterScale(1);
      }
    };

    window.addEventListener('resize', handleResize);
    handleResize();
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  useEffect(() => {
    if (contentRef.current) {
      const baseHeight = contentRef.current.offsetHeight;
      const paddedHeight = baseHeight + 0;
      setAdjustedHeight(paddedHeight * footerScale);
      setLoaded(true);
    }
  }, [footerScale]);

  const openModalAt = (modalId) => {
    setScrollY(window.scrollY);
    window.__isModalOpen = true;
    setOpenModal(modalId);
  };

  const closeModal = () => {
    setOpenModal(null);
    window.__isModalOpen = false;
    document.body.style.position = "";
    document.body.style.top = "";
    document.body.style.width = "";
    document.body.style.overflow = "";
    document.body.style.touchAction = "";
    setTimeout(() => {
      window.scrollTo({ top: scrollY, behavior: "auto" });
    }, 50);
  };

  return (
    <div className="w-full flex justify-center overflow-x-visible pt-[50px] pb-[50px]" style={{ minHeight: adjustedHeight, backgroundColor: '#3D3D3D' }}>
      <div
        ref={contentRef}
        className="w-full flex flex-col items-start min-w-[1920px]"
        style={{
          zoom: footerScale / layoutScale,
          transformOrigin: 'top center',
          paddingLeft: '369px',
          transform: window.innerWidth <= 1200 ? 'translateX(400px)' : 'translateX(0)',
        }}
      >
        <img src="/B_footer.svg" alt="footer-part1" />
        <div className="mt-[10px]" />
        <img src="/B_footer1.svg" alt="footer-part2" />
        <div className="mt-[20px]" />
        <img src="/B_footer2.svg" alt="footer-part3" />
        <div className="mt-[0px] flex items-center">
          <div
            onClick={() => openModalAt('info1')}
            className="hover:opacity-80 transition-all duration-300 mr-[14px] cursor-pointer"
          >
            <img src="/footer1.svg" alt="서비스 이용약관" />
          </div>
          <img src="/footerline.svg" alt="line1" className="mr-[14px]" />
          <div
            onClick={() => openModalAt('info2')}
            className="hover:opacity-80 transition-all duration-300 mr-[14px] cursor-pointer"
          >
            <img src="/footer2.svg" alt="개인정보 처리방침" />
          </div>
          <img src="/footerline.svg" alt="line2" className="mr-[14px]" />
          <div
            onClick={() => openModalAt('info3')}
            className="hover:opacity-80 transition-all duration-300 cursor-pointer"
          >
            <img src="/footer3.svg" alt="마케팅 정보 수신동의" />
          </div>
        </div>
        <div className="mt-[10px]" />
        <img src="/footerend.svg" alt="footer-end" />
      </div>

      <TermsModal isOpen={openModal === 'info1'} onClose={closeModal}>
        <Info1 />
      </TermsModal>
      <TermsModal isOpen={openModal === 'info2'} onClose={closeModal}>
        <Info2 />
      </TermsModal>
      <TermsModal isOpen={openModal === 'info3'} onClose={closeModal}>
        <Info3 />
      </TermsModal>
    </div>
  );
};

export default Footer;
