import React from 'react';

const MobileHeader = ({ mobileScale = 1 }) => {
  return (
    <div className="block custom-819:block hidden">
      {/* 상단 모바일 배너 */}
      <div
        className="w-full h-[52px] bg-[#00A9A4] mx-auto flex flex-col items-center justify-center"
        style={{
          height: `${52 * mobileScale}px`,
        }}
      >
        <span
          style={{
            fontFamily: 'Paperlogy-4Regular',
            fontSize: `${15 * mobileScale}px`,
            lineHeight: `${18 * mobileScale}px`,
          }}
          className="text-white"
        >
          장애인 고용부담금 감면
        </span>
        <span
          style={{
            fontFamily: 'Paperlogy-7Bold',
            fontSize: `${20 * mobileScale}px`,
            lineHeight: `${20 * mobileScale}px`,
          }}
          className="text-[#FFD400] font-bold"
        >
          지금 문의하기 <span className="text-white">{`>`}</span>
        </span>
      </div>
    </div>
  );
};

export default MobileHeader;