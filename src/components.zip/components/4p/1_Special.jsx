import React, { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom'; // Link 임포트 추가


const RelatedEmploymentSection = () => {
  const [scale, setScale] = useState(1);
  const [sectionHeight, setSectionHeight] = useState(null);
  const contentRef = useRef();

  useEffect(() => {
    const handleResize = () => {
      const screenWidth = window.innerWidth;
      if (screenWidth <= 1200) {
        setScale(2);
      } else {
        setScale(1);
      }
    };

    window.addEventListener('resize', handleResize);
    handleResize();
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  useEffect(() => {
    const updateHeight = () => {
      if (contentRef.current) {
        const rawHeight = contentRef.current.scrollHeight; // 원본 높이
        const scaledHeight = rawHeight * scale; // 시각적 높이
        setSectionHeight(scaledHeight);
      }
    };

    const resizeObserver = new ResizeObserver(updateHeight);
    if (contentRef.current) resizeObserver.observe(contentRef.current);
    setTimeout(updateHeight, 50);

    return () => {
      if (contentRef.current) resizeObserver.unobserve(contentRef.current);
    };
  }, [scale]);

  return (
    <div
      className="w-full flex flex-col items-center pt-[0px]"
      style={{
        height: sectionHeight ? `${sectionHeight}px` : 'auto',
        overflow: 'hidden',
      }}
    >
      <div
        ref={contentRef}
        style={{
          transform: `scale(${scale})`,
          transformOrigin: 'top center',
          width: 'fit-content',
        }}
      >
        <Link to="/1_Special">
        <img src="/B4p/b4_1.svg" alt="3_1" />
        </Link>
        <div className="mt-[3px]" />
        <Link to="/2_Special">
        <img src="/B4p/b4_2.svg" alt="3_1" />
        </Link>
        <div className="mt-[3px]" />
        <Link to="/3_Special">
        <img src="/B4p/b4_3.svg" alt="3_1" />
        </Link>
        <div className="mt-[3px]" />
        <Link to="/4_Special">
        <img src="/B4p/b4_4.svg" alt="3_1" />
        </Link>
        <div className="mt-[3px]" />
        <Link to="/5_Special">
        <img src="/B4p/b4_5.svg" alt="3_1" />
        </Link>
      </div>
    </div>
  );
};

export default RelatedEmploymentSection;
