import React from 'react';
import { Link } from 'react-router-dom';

const NavMenu = () => {
  const menus = [
    { name: '휴대폰', path: '/' },
    { name: '인터넷/TV', path: '/2page' },
    { name: '디바이스', path: '/3page' },
    { name: '특별기획전', path: '/4page' },
  ];

  return (
    <nav className="w-full bg-white flex justify-center overflow-hidden border-t border-b border-black">
      <div className="w-[1920px] h-[95px] flex items-center px-[426px] whitespace-nowrap">
        {/* 로고 */}
        <div className="pr-[93px] shrink-0">
          <Link to="/">
            <img
              src="/B1p/B_title.svg"
              alt="kt바로샵"
              className="h-[30px] object-contain"
            />
          </Link>
        </div>

        {/* 메뉴들 */}
        <div className="flex gap-[35px] shrink-0">
          {menus.map((menu, idx) => (
            <Link
              key={idx}
              to={menu.path}
              className="text-[#3E3E3E] text-[20px]"
              style={{ fontFamily: 'Paperlogy-6SemiBold' }}
            >
              {menu.name}
            </Link>
          ))}
        </div>

        {/* flex 여백 */}
        <div className="flex-grow" />

        {/* 문의하기 */}
        <div className="shrink-0 ml-[350px]">
          <Link
            to="callcenter"
            className="text-[#3E3E3E] text-[13px]"
            style={{ fontFamily: 'Paperlogy-6SemiBold' }}
          >
            문의하기
          </Link>
        </div>
      </div>
    </nav>
  );
};

export default NavMenu;