import React, { lazy, Suspense } from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import TotalAdmin from "./pages/TotalAdmin"; // 실제 경로에 맞게 수정


const Layout = lazy(() => import("./components/0_Layout"));
import HomePage from './pages/HomePage';
import SecondPage from './pages/2Page';
import ThirdPage from './pages/3Page';
import FourPage from './pages/4Page';

const Special1 = lazy(() => import("./components/5p/1_Special"));
const Special2 = lazy(() => import("./components/5p/2_Special"));
const Special3 = lazy(() => import("./components/5p/3_Special"));
const Special4 = lazy(() => import("./components/5p/4_Special"));
const Special5 = lazy(() => import("./components/5p/5_Special"));
const StopBanner = lazy(() => import("./components/4_StopBanner"));
const ScrollToTop = lazy(() => import("./components/other/ScrollToTop"));
const Survey = lazy(() => import("./components/6p/2_PhoneSurveyform"));
const Survey2 = lazy(() => import("./components/6p/3_InternetSurveyform"));

const Info4 = lazy(() => import("./components/other/info4"));
const Info1 = lazy(() => import("./components/other/info1"));
const Info2 = lazy(() => import("./components/other/info2"));
const Info3 = lazy(() => import("./components/other/info3"));


// 새로 추가된 컴포넌트들
const Callcenter = lazy(() => import("./components/6p/1_Callcenter"));
const Center1 = lazy(() => import("./components/5p/1_Center"));
const Center2 = lazy(() => import("./components/5p/2_Center"));
const Center3 = lazy(() => import("./components/5p/3_Center"));
const Center4 = lazy(() => import("./components/5p/4_Center"));


import "./index.css";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <Router>
      <Suspense fallback={<div>Loading...</div>}>
        <ScrollToTop />
        <StopBanner />
        <Routes>
          <Route element={<Layout />}>
            <Route path="/" element={<HomePage />} />
            <Route path="/2page" element={<SecondPage />} />
            <Route path="/3page" element={<ThirdPage />} />
            <Route path="/4page" element={<FourPage />} />
            <Route path="/1_Special" element={<Special1 />} />
            <Route path="/2_Special" element={<Special2 />} />
            <Route path="/3_Special" element={<Special3 />} />
            <Route path="/4_Special" element={<Special4 />} />
            <Route path="/5_Special" element={<Special5 />} />
            <Route path="/info1" element={<Info1 />} />
            <Route path="/info2" element={<Info2 />} />
            <Route path="/info4" element={<Info4 />} />
            <Route path="/info3" element={<Info3 />} />
            <Route path="/2_Surveyform" element={<Survey />} />
            <Route path="/3_Surveyform2" element={<Survey2 />} />
            <Route path="/callcenter" element={<Callcenter />} />
            <Route path="/center1" element={<Center1 />} />
            <Route path="/center2" element={<Center2 />} />
            <Route path="/center3" element={<Center3 />} />
            <Route path="/center4" element={<Center4 />} />
            <Route path="/admin" element={<TotalAdmin />} />
          </Route>
        </Routes>
      </Suspense>
    </Router>
  </React.StrictMode>
);