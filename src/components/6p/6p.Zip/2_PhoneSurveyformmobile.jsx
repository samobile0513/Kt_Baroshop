import React, { useEffect, useRef, useState } from "react";

const MobilePhoneSurvey = ({
  form,
  agreements,
  handleInput,
  handleSelect,
  handleAgreement,
  handleSubmit,
  openModalAt,
  error
}) => {
  const containerRef = useRef(null);
  const [zoom, setZoom] = useState(1);

  const isActive = (field, value) => form[field] === value;

  const boxStyle = (active) =>
    `border rounded-md py-3 text-[16px] text-center ${
      active ? "border-[#FD3941] font-bold text-[#FD3941]" : "border-black text-black"
    }`;

  useEffect(() => {
    const handleResize = () => {
      const width = window.innerWidth;
      const ratio = width <= 819 ? Math.max(Math.min((width / 393) * 3, 3), 3) : 3;
      setZoom(ratio);
    };

    window.addEventListener("resize", handleResize);
    handleResize();
    return () => window.removeEventListener("resize", handleResize);
  }, []);
      
  return (
    <div
      ref={containerRef}
      className="w-full flex justify-center bg-white pt-[50px] pb-[50px]"
      style={{ zoom }}
    >
      <div className="w-[364px] px-4 font-[font-4]">
        <div className="flex flex-col items-center text-center mb-[60px]">
          <h2 className="text-[23.5px] text-[#01A69F] font-[font-8] mb-2">KT휴대폰은 바로 바로샵</h2>
          <h1 className="text-[29.31px] font-bold font-[font-5] mb-2">전국 최저가 요금 확인하기</h1>
          <p className="text-[16.77px]">원하시는 휴대폰 상품을 선택해 주세요.</p>
        </div>

        <div>
          <h3 className="text-[30.75px] font-[font-7] mb-6">가입자 정보</h3>

          <div className="mb-6">
            <label className="text-[20px] block mb-2">이름</label>
            <input
              name="name"
              value={form.name}
              onChange={handleInput}
              placeholder="홍길동"
              className="w-full border p-3 text-[16px]"
            />
          </div>

          <div className="mb-6">
            <label className="text-[20px] block mb-2">생년월일</label>
            <input
              name="birth"
              value={form.birth}
              onChange={handleInput}
              placeholder="생년월일 6자리를 입력해 주세요."
              className="w-full border p-3 text-[16px]"
            />
          </div>

          <div className="mb-6">
            <label className="text-[20px] block mb-2">휴대폰 번호</label>
            <input
              name="phone"
              value={form.phone}
              onChange={handleInput}
              placeholder="010-0000-0000"
              className="w-full border p-3 text-[16px]"
            />
          </div>

          <div className="mb-12">
            <label className="text-[20px] block mb-2">상담신청 단말기</label>
            <input
              name="device"
              value={form.device}
              onChange={handleInput}
              placeholder="예) S25"
              className="w-full border p-3 text-[16px]"
            />
          </div>

          <div className="mb-[70px]">
            <p className="text-[18px] mb-2">가입유형을 선택해 주세요.</p>
            <div className="flex flex-col gap-2">
              {["신규가입", "번호이동", "기기변경"].map((item) => (
                <button
                  key={item}
                  onClick={() => handleSelect("joinType", item)}
                  className={boxStyle(isActive("joinType", item))}
                >
                  {item}
                </button>
              ))}
            </div>
          </div>

          <div className="mb-[70px]">
            <p className="text-[18px] mb-2">단말기 결제방식을 선택해 주세요.</p>
            <div className="grid grid-cols-2 gap-2">
              {["일시불", "24개월", "30개월", "36개월", "48개월"].map((item) => (
                <button
                  key={item}
                  onClick={() => handleSelect("paymentPeriod", item)}
                  className={boxStyle(isActive("paymentPeriod", item))}
                >
                  {item}
                </button>
              ))}
            </div>
          </div>

          <div className="mb-[80px]">
            <p className="text-[18px] mb-2">할인방법 (요금/단말)을 선택해 주세요.</p>
            <div className="space-y-4">
              <button
                onClick={() => handleSelect("discountType", "단말할인")}
                className={`w-full border p-3 rounded-md text-left ${
                  isActive("discountType", "단말할인") ? "border-[#FD3941]" : "border-black"
                }`}
              >
                <div className={`text-[22px] font-bold ${isActive("discountType", "단말할인") ? "text-[#FD3941]" : "text-black"}`}>
                  단말할인
                </div>
                <div className="text-[16px]">공시지원금(기기값 즉시할인)</div>
              </button>

              <button
                onClick={() => handleSelect("discountType", "요금할인")}
                className={`w-full border p-3 rounded-md text-left ${
                  isActive("discountType", "요금할인") ? "border-[#FD3941]" : "border-black"
                }`}
              >
                <div className={`text-[22px] font-bold flex items-center ${isActive("discountType", "요금할인") ? "text-[#FD3941]" : "text-black"}`}>
                  요금할인
                  <span className="ml-2 bg-[#FD3941] text-white px-2 py-[1px] rounded-full text-[12px]">추천</span>
                </div>
                <div className="text-[16px]">24개월간 매월 요금 25% 할인</div>
              </button>
            </div>
          </div>

          <div className="mb-[80px]">
            <h3 className="text-[20px] font-[font-7] mb-2">기타 요청사항</h3>
            <textarea
              name="additional"
              value={form.additional}
              onChange={handleInput}
              rows={5}
              className="w-full border p-3 text-[14px]"
              placeholder="추가로 상담 받고 싶은 내용을 적어주세요."
            />
          </div>

          <div className="mt-10">
            <div className="flex items-center gap-2 mb-2">
              <input
                type="checkbox"
                name="all"
                checked={agreements.all}
                onChange={handleAgreement}
              />
              <span className="text-black text-[16px]">전체 동의합니다.</span>
            </div>

            <div className="flex flex-col gap-2">
              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  name="terms"
                  checked={agreements.terms}
                  onChange={handleAgreement}
                />
                <span
                  onClick={() => openModalAt("info1")}
                  className="underline cursor-pointer text-black text-[15px]"
                >
                  서비스 이용약관 <span className="text-[12px]">(필수)</span>
                </span>
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  name="privacy"
                  checked={agreements.privacy}
                  onChange={handleAgreement}
                />
                <span
                  onClick={() => openModalAt("info2")}
                  className="underline cursor-pointer text-black text-[15px]"
                >
                  개인정보처리방침 <span className="text-[12px]">(필수)</span>
                </span>
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  name="marketing"
                  checked={agreements.marketing}
                  onChange={handleAgreement}
                />
                <span
                  onClick={() => openModalAt("info3")}
                  className="underline cursor-pointer text-black text-[15px]"
                >
                  마케팅 정보수신 동의 <span className="text-[12px]">(선택)</span>
                </span>
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  name="thirdParty"
                  checked={agreements.thirdParty}
                  onChange={handleAgreement}
                />
                <span
                  onClick={() => openModalAt("info4")}
                  className="underline cursor-pointer text-black text-[15px]"
                >
                  개인정보 수집 및 이용, 제3자 동의서 자세히 보기 <span className="text-[12px]">(선택)</span>
                </span>
              </div>
            </div>
          </div>

          <button
            onClick={handleSubmit}
            className="mt-10 w-full bg-[#00B7A3] text-white py-4 rounded-md text-[18px]"
          >
            상담 예약
          </button>

          {error && <p className="text-red-500 text-[14px] mt-4">{error}</p>}
        </div>
      </div>
    </div>
  );
};

export default MobilePhoneSurvey;