import React, { useEffect, useRef, useState } from "react";

const MobileInternetSurvey = ({
  form,
  agreements,
  handleInput,
  handleSelect,
  handleAgreement,
  handleSubmit,
  openModalAt,
  error
}) => {
  const containerRef = useRef(null);
  const [zoom, setZoom] = useState(1);

  const isActive = (field, value) => form[field] === value;

  const boxStyle = (active) =>
    `border rounded-md py-3 text-[16px] text-center ${
      active ? "border-[#FD3941] font-bold text-[#FD3941]" : "border-black text-black"
    }`;

  useEffect(() => {
    const handleResize = () => {
      const width = window.innerWidth;
      const ratio = width <= 819 ? Math.max(Math.min((width / 393) * 3, 3), 3) : 3;
      setZoom(ratio);
    };

    window.addEventListener("resize", handleResize);
    handleResize();
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  return (
    <div
      ref={containerRef}
      className="w-full flex justify-center bg-white pt-[50px] pb-[50px]"
      style={{ zoom, minHeight: `${window.innerHeight / zoom}px` }}
    >
      <div className="w-[364px] px-4 font-[font-4]">
        <div className="flex flex-col items-center text-center mb-[60px]">
          <h2 className="text-[23.5px] text-[#01A69F] font-[font-8] mb-2">KT인터넷은 바로 바로샵</h2>
          <h1 className="text-[29.31px] font-bold font-[font-5] mb-2">전국 최저가 요금 확인하기</h1>
          <p className="text-[16.77px]">원하시는 인터넷 상품을 선택해 주세요.</p>
        </div>

        <div>
          <h3 className="text-[30.75px] font-[font-7] mb-6">가입자 정보</h3>

          <div className="mb-6">
            <label className="text-[20px] block mb-2">이름</label>
            <input
              name="name"
              value={form.name}
              onChange={handleInput}
              placeholder="홍길동"
              className="w-full border p-3 text-[16px]"
            />
          </div>

          <div className="mb-6">
            <label className="text-[20px] block mb-2">생년월일</label>
            <input
              name="birth"
              value={form.birth}
              onChange={handleInput}
              placeholder="생년월일 6자리를 입력해 주세요."
              className="w-full border p-3 text-[16px]"
            />
          </div>

          <div className="mb-6">
            <label className="text-[20px] block mb-2">휴대폰 번호</label>
            <input
              name="phone"
              value={form.phone}
              onChange={handleInput}
              placeholder="010-0000-0000"
              className="w-full border p-3 text-[16px]"
            />
          </div>

          <div className="mb-12">
            <label className="text-[20px] block mb-2">주소</label>
            <input
              name="address"
              value={form.address}
              onChange={handleInput}
              placeholder="설치 희망 주소를 입력해 주세요."
              className="w-full border p-3 text-[16px]"
            />
          </div>

          <div className="mb-[70px]">
            <p className="text-[18px] mb-2">가입유형을 선택해 주세요.</p>
            <div className="flex flex-col gap-2">
              {["인터넷", "인터넷+TV", "인터넷+TV+휴대폰"].map((item) => (
                <button
                  key={item}
                  onClick={() => handleSelect("joinType", item)}
                  className={boxStyle(isActive("joinType", item))}
                >
                  {item}
                </button>
              ))}
            </div>
          </div>

          <div className="mb-[70px]">
            <p className="text-[18px] mb-2">사은품을 선택해 주세요.</p>
            <div className="grid grid-cols-2 gap-2">
              {["상품권", "가전제품"].map((item) => (
                <button
                  key={item}
                  onClick={() => handleSelect("giftType", item)}
                  className={boxStyle(isActive("giftType", item))}
                >
                  {item}
                </button>
              ))}
            </div>
          </div>

          <div className="mb-[80px]">
            <h3 className="text-[20px] font-[font-7] mb-2">기타 요청사항</h3>
            <textarea
              name="additional"
              value={form.additional}
              onChange={handleInput}
              rows={5}
              className="w-full border p-3 text-[14px]"
              placeholder="추가로 상담 받고 싶은 내용을 적어주세요."
            />
          </div>

          <div className="mt-10">
            <div className="flex items-center gap-2 mb-2">
              <input
                type="checkbox"
                name="all"
                checked={agreements.all}
                onChange={handleAgreement}
              />
              <span className="text-black text-[16px]">전체 동의합니다.</span>
            </div>

            <div className="flex flex-col gap-2">
              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  name="terms"
                  checked={agreements.terms}
                  onChange={handleAgreement}
                />
                <span
                  onClick={() => openModalAt("info1")}
                  className="underline cursor-pointer text-black text-[15px]"
                >
                  서비스 이용약관 <span className="text-[12px]">(필수)</span>
                </span>
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  name="privacy"
                  checked={agreements.privacy}
                  onChange={handleAgreement}
                />
                <span
                  onClick={() => openModalAt("info2")}
                  className="underline cursor-pointer text-black text-[15px]"
                >
                  개인정보처리방침 <span className="text-[12px]">(필수)</span>
                </span>
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  name="marketing"
                  checked={agreements.marketing}
                  onChange={handleAgreement}
                />
                <span
                  onClick={() => openModalAt("info3")}
                  className="underline cursor-pointer text-black text-[15px]"
                >
                  마케팅 정보수신 동의 <span className="text-[12px]">(선택)</span>
                </span>
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  name="thirdParty"
                  checked={agreements.thirdParty}
                  onChange={handleAgreement}
                />
                <span
                  onClick={() => openModalAt("info4")}
                  className="underline cursor-pointer text-black text-[15px]"
                >
                  개인정보 수집 및 이용, 제3자 동의서 자세히 보기 <span className="text-[12px]">(선택)</span>
                </span>
              </div>
            </div>
          </div>

          <button
            onClick={handleSubmit}
            className="mt-10 w-full bg-[#00B7A3] text-white py-4 rounded-md text-[18px]"
          >
            상담 예약
          </button>

          {error && <p className="text-red-500 text-[14px] mt-4">{error}</p>}
        </div>
      </div>
    </div>
  );
};

export default MobileInternetSurvey;
